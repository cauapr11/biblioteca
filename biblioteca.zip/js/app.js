// ── Alert ─────────────────────────────────────────────────────
function showAlert(msg, type = 'success') {
  let el = document.getElementById('global-alert');
  if (!el) {
    el = document.createElement('div');
    el.id = 'global-alert';
    el.className = 'alert';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.className = `alert alert-${type} show`;
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3000);
}

// ── Modal ─────────────────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
  if (e.target.classList.contains('modal-close')) {
    e.target.closest('.modal-overlay').classList.remove('open');
    document.body.style.overflow = '';
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

// ── Tabs ──────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('[data-tab-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.dataset.tabGroup;
      document.querySelectorAll(`[data-tab-group="${group}"]`).forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const target = btn.dataset.tabTarget;
      document.querySelectorAll(`[data-tab-panel="${group}"]`).forEach(p => {
        p.style.display = p.dataset.tabId === target ? '' : 'none';
      });
    });
  });
}

// ── Filter buttons ────────────────────────────────────────────
function initFilterBtns() {
  document.querySelectorAll('[data-filter-group]').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.dataset.filterGroup;
      document.querySelectorAll(`[data-filter-group="${group}"]`).forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}

// ── Search filter (client-side) ───────────────────────────────
function initSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// ── Confirm delete ────────────────────────────────────────────
function confirmDelete(msg, url) {
  if (!confirm(msg)) return;
  fetch(url, { method: 'DELETE' })
    .then(r => r.json())
    .then(data => {
      if (data.ok) { showAlert('Excluído com sucesso.'); setTimeout(() => location.reload(), 900); }
      else showAlert(data.erro || 'Erro ao excluir.', 'error');
    });
}

// ── Fetch form helper ─────────────────────────────────────────
function submitForm(formId, apiUrl, modalId, successMsg) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    const method = body.id ? 'PUT' : 'POST';
    try {
      const r = await fetch(apiUrl, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await r.json();
      if (data.ok) {
        showAlert(successMsg);
        closeModal(modalId);
        setTimeout(() => location.reload(), 900);
      } else {
        showAlert(data.erro || 'Erro ao salvar.', 'error');
      }
    } catch { showAlert('Erro de comunicação.', 'error'); }
  });
}

// ── Loan: marcar como devolvido ───────────────────────────────
function devolverEmprestimo(id) {
  if (!confirm('Confirmar devolução deste livro?')) return;
  fetch(`api/emprestimos.php?id=${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, action: 'devolver' })
  })
    .then(r => r.json())
    .then(data => {
      if (data.ok) { showAlert('Devolução registrada!'); setTimeout(() => location.reload(), 900); }
      else showAlert(data.erro || 'Erro ao registrar.', 'error');
    });
}

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initFilterBtns();
});
