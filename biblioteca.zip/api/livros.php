<?php
session_start();
if (!isset($_SESSION['admin_id'])) { http_response_code(401); exit; }

header('Content-Type: application/json; charset=utf-8');
require_once '../config/connect.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ── DELETE ────────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) { json_out(['erro' => 'ID inválido.'], 400); }
    // Verifica empréstimos ativos
    $em = db_query($conn, "SELECT COUNT(*) AS c FROM tbemprestimos WHERE idlivro=? AND status!='devolvido'", 'i', [$id]);
    if ($em->fetch_assoc()['c'] > 0) { json_out(['erro' => 'Livro possui empréstimo em aberto.'], 409); }
    db_query($conn, 'DELETE FROM tblivros WHERE idlivro=?', 'i', [$id]);
    json_out(['ok' => true]);
}

// ── POST / PUT ────────────────────────────────────────────────
if (in_array($method, ['POST', 'PUT'])) {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) { json_out(['erro' => 'Dados inválidos.'], 400); }

    $titulo    = trim($body['titulo'] ?? '');
    $autor     = trim($body['autor'] ?? '');
    $editora   = trim($body['editora'] ?? '');
    $ano       = (int)($body['ano'] ?? 0) ?: null;
    $isbn      = trim($body['isbn'] ?? '');
    $categoria = trim($body['categoria'] ?? '');
    $qtd       = max(1, (int)($body['quantidade'] ?? 1));
    $disp      = max(0, (int)($body['quantidadedisponivel'] ?? $qtd));
    $estante   = trim($body['estante'] ?? '');
    $prateleira= trim($body['prateleira'] ?? '');
    $bid       = (int)($body['id'] ?? 0);

    if (!$titulo) { json_out(['erro' => 'Título é obrigatório.'], 422); }

    if ($bid) {
        db_query($conn,
            'UPDATE tblivros SET titulo=?,autor=?,editora=?,ano=?,isbn=?,categoria=?,quantidade=?,quantidadedisponivel=?,estante=?,prateleira=? WHERE idlivro=?',
            'ssssissssi',
            [$titulo, $autor, $editora, $ano, $isbn, $categoria, $qtd, $disp, $estante, $prateleira, $bid]
        );
        json_out(['ok' => true, 'id' => $bid]);
    } else {
        db_query($conn,
            'INSERT INTO tblivros (titulo,autor,editora,ano,isbn,categoria,quantidade,quantidadedisponivel,estante,prateleira) VALUES (?,?,?,?,?,?,?,?,?,?)',
            'ssssissss',
            [$titulo, $autor, $editora, $ano, $isbn, $categoria, $qtd, $disp, $estante, $prateleira]
        );
        json_out(['ok' => true, 'id' => $conn->insert_id]);
    }
}

json_out(['erro' => 'Método não suportado.'], 405);
