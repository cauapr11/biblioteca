<?php
session_start();
if (!isset($_SESSION['admin_id'])) { http_response_code(401); exit; }

header('Content-Type: application/json; charset=utf-8');
require_once '../config/connect.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ── PUT: devolver ou atualizar ────────────────────────────────
if ($method === 'PUT') {
    $body = json_decode(file_get_contents('php://input'), true);
    $eid  = (int)($body['id'] ?? $id);

    if (!$eid) { json_out(['erro' => 'ID inválido.'], 400); }

    // Ação: devolver
    if (($body['action'] ?? '') === 'devolver') {
        $emp = db_query($conn, 'SELECT idlivro, status FROM tbemprestimos WHERE idemprestimo=?', 'i', [$eid]);
        $row = $emp->fetch_assoc();
        if (!$row) { json_out(['erro' => 'Empréstimo não encontrado.'], 404); }
        if ($row['status'] === 'devolvido') { json_out(['erro' => 'Já devolvido.'], 409); }

        $conn->begin_transaction();
        try {
            db_query($conn,
                "UPDATE tbemprestimos SET status='devolvido', datadevolucao=CURDATE() WHERE idemprestimo=?",
                'i', [$eid]
            );
            db_query($conn,
                'UPDATE tblivros SET quantidadedisponivel = quantidadedisponivel + 1 WHERE idlivro=?',
                'i', [$row['idlivro']]
            );
            $conn->commit();
            json_out(['ok' => true]);
        } catch (Exception $e) {
            $conn->rollback();
            json_out(['erro' => 'Erro ao registrar devolução.'], 500);
        }
    }

    json_out(['erro' => 'Ação desconhecida.'], 400);
}

// ── POST: novo empréstimo ─────────────────────────────────────
if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) { json_out(['erro' => 'Dados inválidos.'], 400); }

    $idusuario      = (int)($body['idusuario']      ?? 0);
    $idlivro        = (int)($body['idlivro']         ?? 0);
    $dataemprestimo = trim($body['dataemprestimo']   ?? date('Y-m-d'));
    $dataprevista   = trim($body['dataprevista']     ?? '');

    if (!$idusuario || !$idlivro || !$dataprevista) {
        json_out(['erro' => 'Usuário, livro e data prevista são obrigatórios.'], 422);
    }

    // Verifica disponibilidade
    $livro = db_query($conn, 'SELECT quantidadedisponivel FROM tblivros WHERE idlivro=?', 'i', [$idlivro]);
    $lrow  = $livro->fetch_assoc();
    if (!$lrow || $lrow['quantidadedisponivel'] < 1) {
        json_out(['erro' => 'Livro sem exemplares disponíveis.'], 409);
    }

    // Verifica se usuário já tem o mesmo livro emprestado
    $dup = db_query($conn,
        "SELECT COUNT(*) AS c FROM tbemprestimos WHERE idusuario=? AND idlivro=? AND status!='devolvido'",
        'ii', [$idusuario, $idlivro]
    );
    if ($dup->fetch_assoc()['c'] > 0) {
        json_out(['erro' => 'Usuário já possui este livro emprestado.'], 409);
    }

    $conn->begin_transaction();
    try {
        db_query($conn,
            "INSERT INTO tbemprestimos (idusuario, idlivro, dataemprestimo, dataprevista, status) VALUES (?,?,?,?,'ativo')",
            'iiss', [$idusuario, $idlivro, $dataemprestimo, $dataprevista]
        );
        db_query($conn,
            'UPDATE tblivros SET quantidadedisponivel = quantidadedisponivel - 1 WHERE idlivro=?',
            'i', [$idlivro]
        );
        $conn->commit();
        json_out(['ok' => true, 'id' => $conn->insert_id]);
    } catch (Exception $e) {
        $conn->rollback();
        json_out(['erro' => 'Erro ao registrar empréstimo.'], 500);
    }
}

json_out(['erro' => 'Método não suportado.'], 405);
