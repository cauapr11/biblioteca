<?php
session_start();
if (!isset($_SESSION['admin_id'])) { http_response_code(401); exit; }

header('Content-Type: application/json; charset=utf-8');
require_once '../config/connect.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ── DELETE ────────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) { json_out(['erro' => 'ID inválido.'], 400); }
    $em = db_query($conn, "SELECT COUNT(*) AS c FROM tbemprestimos WHERE idusuario=? AND status!='devolvido'", 'i', [$id]);
    if ($em->fetch_assoc()['c'] > 0) { json_out(['erro' => 'Usuário possui empréstimo em aberto.'], 409); }
    db_query($conn, 'DELETE FROM tbusuarios WHERE idusuario=?', 'i', [$id]);
    json_out(['ok' => true]);
}

// ── POST / PUT ────────────────────────────────────────────────
if (in_array($method, ['POST', 'PUT'])) {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) { json_out(['erro' => 'Dados inválidos.'], 400); }

    $nome      = trim($body['nome']      ?? '');
    $matricula = trim($body['matricula'] ?? '') ?: null;
    $tipo      = in_array($body['tipo'] ?? '', ['aluno','professor','funcionario']) ? $body['tipo'] : 'aluno';
    $curso     = trim($body['curso']     ?? '');
    $serie     = trim($body['serie']     ?? '');
    $turma     = trim($body['turma']     ?? '');
    $telefone  = trim($body['telefone']  ?? '');
    $email     = trim($body['email']     ?? '');
    $status    = in_array($body['status'] ?? '', ['ativo','inativo']) ? $body['status'] : 'ativo';
    $uid       = (int)($body['id'] ?? 0);

    if (!$nome) { json_out(['erro' => 'Nome é obrigatório.'], 422); }

    if ($uid) {
        db_query($conn,
            'UPDATE tbusuarios SET nome=?,matricula=?,tipo=?,curso=?,serie=?,turma=?,telefone=?,email=?,status=? WHERE idusuario=?',
            'ssssssssi',
            [$nome, $matricula, $tipo, $curso, $serie, $turma, $telefone, $email, $status, $uid]
        );
        json_out(['ok' => true, 'id' => $uid]);
    } else {
        db_query($conn,
            'INSERT INTO tbusuarios (nome,matricula,tipo,curso,serie,turma,telefone,email,status) VALUES (?,?,?,?,?,?,?,?,?)',
            'sssssssss',
            [$nome, $matricula, $tipo, $curso, $serie, $turma, $telefone, $email, $status]
        );
        json_out(['ok' => true, 'id' => $conn->insert_id]);
    }
}

json_out(['erro' => 'Método não suportado.'], 405);
