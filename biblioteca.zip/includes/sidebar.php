<?php
$pagina_atual = basename($_SERVER['PHP_SELF'], '.php');
$admin_nome = $_SESSION['admin_nome'] ?? 'Administrador';
$iniciais = implode('', array_map(fn($p) => strtoupper($p[0]), array_slice(explode(' ', $admin_nome), 0, 2)));

$nav = [
  ['href' => 'painel.php',      'key' => 'painel',      'label' => 'Painel',        'icon' => '<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>'],
  ['href' => 'livros.php',      'key' => 'livros',      'label' => 'Acervo',        'icon' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'],
  ['href' => 'emprestimos.php', 'key' => 'emprestimos', 'label' => 'Empréstimos',   'icon' => '<path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><rect x="9" y="3" width="6" height="4" rx="1" stroke="currentColor" stroke-width="2"/><path d="m9 12 2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'],
  ['href' => 'usuarios.php',    'key' => 'usuarios',    'label' => 'Usuários',      'icon' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke="currentColor" stroke-width="2"/><path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'],
];
?>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="sidebar-logo-icon">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </div>
    <div>
      <div class="sidebar-logo-title">BiblioEscola</div>
      <div class="sidebar-logo-sub">Sistema de Biblioteca</div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-label">Menu</div>
    <?php foreach ($nav as $item): ?>
      <a href="<?= $item['href'] ?>" class="nav-item <?= $pagina_atual === $item['key'] ? 'active' : '' ?>">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><?= $item['icon'] ?></svg>
        <?= $item['label'] ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="sidebar-user">
    <div class="sidebar-avatar"><?= htmlspecialchars($iniciais) ?></div>
    <div>
      <div class="sidebar-user-name"><?= htmlspecialchars($admin_nome) ?></div>
      <div class="sidebar-user-role">Administrador</div>
    </div>
  </div>
  <a href="logout.php" class="sidebar-logout">Sair do sistema</a>
</aside>
